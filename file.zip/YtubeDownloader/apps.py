from django.apps import AppConfig


class YtubedownloaderConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'YtubeDownloader'
